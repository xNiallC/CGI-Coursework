Niall Curtis
C1623580
CurtisNS@cardiff.ac.uk
https://submission.cs.cf.ac.uk/CurtisNS/exercise2/